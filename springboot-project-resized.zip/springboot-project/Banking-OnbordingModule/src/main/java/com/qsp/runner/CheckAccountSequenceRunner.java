package com.qsp.runner;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.qsp.controller.OtpController;
import com.qsp.entity.AccountSequenceNumber;
import com.qsp.repository.AccountSequenceRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CheckAccountSequenceRunner implements CommandLineRunner {
	
	@Autowired
	private AccountSequenceRepository accountsequencerepo;
	@Override
	public void run(String... args) throws Exception {
		Optional<AccountSequenceNumber> opt=accountsequencerepo
				.findById(1);
		if(opt.isEmpty()) {
			log.info("base sequence creating");
			accountsequencerepo.save(new AccountSequenceNumber(1,1000));
		}
		else {
			log.info("sequence is already present in db");
		}
	}

}
