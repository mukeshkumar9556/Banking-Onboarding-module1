package com.qsp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.entity.AccountSequenceNumber;

public interface AccountSequenceRepository extends JpaRepository<AccountSequenceNumber,Integer> {

}
