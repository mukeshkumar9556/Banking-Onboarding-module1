package com.qsp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.entity.JourneySequenceGenerater;

public interface JourneySequenceGeneraterRepo extends 
                         JpaRepository<JourneySequenceGenerater,Integer>{

}
