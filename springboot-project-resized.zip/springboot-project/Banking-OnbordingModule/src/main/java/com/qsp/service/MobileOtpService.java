package com.qsp.service;

public interface MobileOtpService {
	String sendOtp(String toPhoneNumber);
	String verifyOtpService(String mobileNumber,String otp);
}
