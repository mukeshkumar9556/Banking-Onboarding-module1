package com.qsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.qsp.service.ImageDocumentService;

import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/image")
@Slf4j
public class ImageDocumentController {
	@Autowired
	private ImageDocumentService imageserce;
	@PostMapping("/aadhar")
	public String storeAadharCardApi(@RequestParam("file") MultipartFile file) {
		log.info("request for storing aadhar is made");
		return imageserce.StoreAadharService(file);
	}
}
