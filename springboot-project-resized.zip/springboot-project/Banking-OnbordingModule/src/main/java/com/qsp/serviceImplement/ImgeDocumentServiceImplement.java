package com.qsp.serviceImplement;

import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.qsp.service.ImageDocumentService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ImgeDocumentServiceImplement implements ImageDocumentService{

	@Override
	public String StoreAadharService(MultipartFile file) {
		//@ToDo the cloud service to store the image and accept the url
		log.info("creating a mock url for stored image");
		String id=UUID.randomUUID().toString();
		return "https://aws.com/s3/bucket"+id;
	}

}
