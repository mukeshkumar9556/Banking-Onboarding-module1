package com.qsp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<?> handleRuntimeException(RuntimeException ex){
		return new ResponseEntity<>("Unpected error while executing logic",
				HttpStatus.NOT_IMPLEMENTED);
	}
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<?> handleillegalArgumentException(IllegalArgumentException ex) {
		return new ResponseEntity<>("Improper request",
				HttpStatus.BAD_REQUEST);
	}
}
