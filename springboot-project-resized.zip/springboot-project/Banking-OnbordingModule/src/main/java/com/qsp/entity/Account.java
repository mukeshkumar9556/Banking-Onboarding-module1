package com.qsp.entity;

import com.qsp.dto.BioDataDTO;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Account {
	private String name;
	private String dob;
	private String parentName;
	private String address;
	private String pin;
	private Double yearlyIncome;
	private String occupation;
	private String nominyName;
	private String relationWithNominy;
	private Boolean isMarried;
	private String nationality;
	private String accountType;
	private String branchCode;
	private String aadharNumber;
	private String panNUmber;
	@Id
	private String accountNumber;
	private String netBankingId;
	private Double currentBalance;
	private String mpin;
	public Account(BioDataDTO biodate,String accountnumber,String netbankingid,
			                             String mpin) {
		this.name=biodate.getName();
		this.address=biodate.getAddress();
		this.dob=biodate.getDob();
		this.parentName=biodate.getParentName();
		this.pin=biodate.getPin();
		this.yearlyIncome=biodate.getYearlyIncome();
		this.occupation=biodate.getOccupation();
		this.nominyName=biodate.getNominyName();
		this.relationWithNominy=biodate.getRelationWithNominy();
		this.isMarried=biodate.getIsMarried();
		this.nationality=biodate.getNationality();
		this.accountType=biodate.getAccountType();
		this.branchCode=biodate.getBranchCode();
		this.aadharNumber=biodate.getAadharNumber();
		this.panNUmber=biodate.getPanNUmber();
		this.currentBalance=0.0;
		this.accountNumber=accountnumber;
		this.netBankingId=netbankingid;
		this.mpin=mpin;
	}
}
