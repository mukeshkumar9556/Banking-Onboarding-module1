package com.qsp.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.dto.BioDataDTO;
import com.qsp.entity.Account;
import com.qsp.entity.AccountSequenceNumber;
import com.qsp.repository.AccountRepository;
import com.qsp.repository.AccountSequenceRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepo;
	@Autowired
	private AccountSequenceRepository accountSequeceRepo;
	public Account createNewAccount(BioDataDTO biodatadto) {
		Optional<AccountSequenceNumber> opt1=accountSequeceRepo
				.findById(1);
		String accountNumber=biodatadto.getBranchCode()+opt1.get().getSequenceNumber();
		int tempsequence=opt1.get().getSequenceNumber();
		tempsequence++;
		opt1.get().setSequenceNumber(tempsequence);
		accountSequeceRepo.save(opt1.get());
		String netBankingId=accountNumber+LocalDate.now().toString();
		String mpin=netBankingId;
		Account account=new Account(biodatadto, accountNumber, netBankingId, mpin);
		accountRepo.save(account);
		return account;
	}
}
