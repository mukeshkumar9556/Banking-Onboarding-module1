package com.qsp.serviceImplement;

import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.qsp.service.GamilOTPService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GmailOTPServiceImplement implements GamilOTPService{
	
	@Autowired
    private JavaMailSender mailSender;
	
	@Autowired
	@Qualifier("otpHolder")
	private Map<String, String> otpHolder;
	
	@Override
	public void sendEmail(String to) {
		String otp=otpGenerator();
		SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("testsubhabrata736@gmail.com");
        message.setTo(to);
        message.setSubject("OTP");
        message.setText("OTP for gmail verification : "+otp);
        mailSender.send(message);
        otpHolder.put(to,otp);
        log.info(otpHolder.toString());
	}
	private String otpGenerator() {
		String otp="";
		for(int i=1;i<=6;i++)
			otp=otp+new Random().nextInt(10);
		return otp;
	}
	
	@Override
	public String varifyEmailOtp(String email,String otp) {
		return otpHolder.get(email).equals(otp)?"Otp verified sucessfully":
				 "Wrong otp entered";
	}

}
