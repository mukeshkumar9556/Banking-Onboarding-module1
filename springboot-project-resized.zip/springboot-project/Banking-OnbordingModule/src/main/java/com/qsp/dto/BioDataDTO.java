package com.qsp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BioDataDTO {
	private String name;
	private String dob;
	private String parentName;
	private String address;
	private String pin;
	private Double yearlyIncome;
	private String occupation;
	private String nominyName;
	private String relationWithNominy;
	private Boolean isMarried;
	private String nationality;
	private String accountType;
	private String branchCode;
	private String aadharNumber;
	private String panNUmber;
}
