package com.qsp.service;

import org.springframework.web.multipart.MultipartFile;

public interface ImageDocumentService {
	String StoreAadharService(MultipartFile file);
}
