package com.qsp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.entity.Journey;

public interface JourneyRepository extends JpaRepository<Journey,String>{

}
