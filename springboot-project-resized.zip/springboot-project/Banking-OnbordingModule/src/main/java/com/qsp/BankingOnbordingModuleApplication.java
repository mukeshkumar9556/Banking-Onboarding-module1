package com.qsp;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BankingOnbordingModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingOnbordingModuleApplication.class, args);
	}
	
	@Bean("otpHolder")
	public Map<String, String> getOptHolder(){
		return new HashMap<String, String>();
	}
}
