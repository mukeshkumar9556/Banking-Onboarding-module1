package com.qsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.dto.BioDataDTO;
import com.qsp.entity.Account;
import com.qsp.service.AccountService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/biodata")
public class BioDataCollector {
	@Autowired
	private AccountService accountService;
	@PostMapping
	public Account collectBiodata(@RequestBody BioDataDTO biodatadto) {
		log.info(biodatadto.toString());
		return accountService.createNewAccount(biodatadto);
	}
}
