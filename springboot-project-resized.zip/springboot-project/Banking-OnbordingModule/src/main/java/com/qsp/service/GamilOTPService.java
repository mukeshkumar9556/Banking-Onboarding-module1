package com.qsp.service;

public interface GamilOTPService {
	void sendEmail(String t0);
	String varifyEmailOtp(String email,String otp);
}
