package com.qsp.runner;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.qsp.entity.JourneySequenceGenerater;
import com.qsp.repository.JourneySequenceGeneraterRepo;

@Component
public class JourneySequenceGeneraterRunner implements CommandLineRunner {

	@Autowired
	private JourneySequenceGeneraterRepo journeyDequenceRepo;
	@Override
	public void run(String... args) throws Exception {
		Optional<JourneySequenceGenerater> opt=
				                  journeyDequenceRepo.findById(1);
		if(opt.isEmpty()) {
			JourneySequenceGenerater sequence=new JourneySequenceGenerater(1,1);
			journeyDequenceRepo.save(sequence);
		}
	}

}
