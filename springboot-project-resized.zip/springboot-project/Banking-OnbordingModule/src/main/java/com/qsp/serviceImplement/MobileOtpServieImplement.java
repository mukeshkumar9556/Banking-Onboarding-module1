package com.qsp.serviceImplement;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.qsp.entity.Journey;
import com.qsp.entity.JourneySequenceGenerater;
import com.qsp.repository.JourneyRepository;
import com.qsp.repository.JourneySequenceGeneraterRepo;
import com.qsp.service.MobileOtpService;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@Service
public class MobileOtpServieImplement implements MobileOtpService {
	
	@Value("${twilio.phone.number}")
    private String fromNumber;
	
	@Autowired
	@Qualifier("otpHolder")
	private Map<String, String> otpHolder;
	
	@Autowired
	private JourneyRepository journeyRepo;
	
	@Autowired
	private JourneySequenceGeneraterRepo journeySequenceRepo;
	
	@Override
	public String sendOtp(String toPhoneNumber) {
	       String otp = generateOtp();

//	        Message message = Message.creator(
//	                new PhoneNumber(toPhoneNumber),  // To number
//	                new PhoneNumber(fromNumber),    // From Twilio number
//	                "Your OTP code is: " + otp
//	        ).create();
	       Map<String, String> holder=otpHolder;
	       holder.put(toPhoneNumber, otp);
	       Optional<JourneySequenceGenerater> generater=journeySequenceRepo.
	    		                                                         findById(1);
	       int current_journeySequence=generater.get().getSequenceNumber();
	       Journey jourey=new Journey(LocalDate.now().toString()+current_journeySequence,"Mobile-otp-generate", 
	    		   toPhoneNumber,"Otp sent to user with number "+toPhoneNumber);
	       journeyRepo.save(jourey);
	       current_journeySequence++;
	       generater.get().setSequenceNumber(current_journeySequence);
	       journeySequenceRepo.save(generater.get());
	        return otp;
	}
	private String generateOtp() {
		
        return String.valueOf(100000 + new Random().nextInt(900000));
    }
	@Override
	public String verifyOtpService(String mobileNumber, String otp) {
		Optional<JourneySequenceGenerater> generater=journeySequenceRepo.
                findById(1);
        int current_journeySequence=generater.get().getSequenceNumber(); //3
        Journey jourey=new Journey(LocalDate.now().toString()+current_journeySequence,"Mobile-otp-verify", 
	    		   mobileNumber,"Otp verified with number "+mobileNumber);
        journeyRepo.save(jourey);
        journeySequenceRepo.save(generater.get());
        current_journeySequence++;
	       generater.get().setSequenceNumber(current_journeySequence);
	       journeySequenceRepo.save(generater.get());
		return otpHolder.get(mobileNumber).equals(otp)?
				"otp verified successfull":"wrong otp given";
	}

}
