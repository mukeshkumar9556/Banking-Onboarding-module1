package com.qsp.service;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;

@Service
public class RozerPayservice {
	private static final String RAZORPAY_KEY = "rzp_test_TJhj6TQQ06UjA6";
    private static final String RAZORPAY_SECRET = "MzAOQa4YWTdy1kvjCuCxujVE";

	public Order createOrderService(Map<String, Object> data) {
        try {
            int amount = (int) data.get("amount") * 100; // Amount in paise

            RazorpayClient client = new RazorpayClient(RAZORPAY_KEY, RAZORPAY_SECRET);

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amount);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "receipt_" + System.currentTimeMillis());
            orderRequest.put("payment_capture", 1);

            Order order = client.orders.create(orderRequest);

            return order;

        } catch (Exception e) {
            throw new RuntimeException("Payment failed");
        }
	}
}
