package com.qsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.service.GamilOTPService;
import com.qsp.service.MobileOtpService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/otp")
@Slf4j
public class OtpController {
	@Autowired
    private MobileOtpService mobileOtpService;
	
	@Autowired
	private GamilOTPService gmailOtpService;
	
	@PostMapping("/send")
	public String OtpGenerater(@RequestParam("mobileNumber") String mobileNumber) {
		log.info("request generated for otp mobile number "+mobileNumber);
		String otp=mobileOtpService.sendOtp(mobileNumber);
		return otp;	
	}
	
	@GetMapping("/verify")
	public String verifyOtp(@RequestParam("mobileNumber") String mobileNumber
			,@RequestParam("otp") String otp) {
		return mobileOtpService.verifyOtpService(mobileNumber, otp);
	}
	
	@PostMapping("/mailotp")
	public void sendOtpMail(@RequestParam("email") String email) {
		gmailOtpService.sendEmail(email);
	}
	@GetMapping("/mailotp")
	public String emailOtpVerifyApi(@RequestParam("email") String email,
			                                        @RequestParam("otp") String otp) {
		return gmailOtpService.varifyEmailOtp(email, otp);
	}
}
